package com.project.ams.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.ams.entity.User;

public interface UserRepositary extends JpaRepository<User, Integer>{
	
	

}
