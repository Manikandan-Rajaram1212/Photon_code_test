package com.project.ams.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.ams.entity.User;
import com.project.ams.repositary.UserRepositary;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserRepositary userrepo;
	
	
	@PostMapping("/adduser")
	public Mono<User> addUser(@RequestBody User user){
		
		 userrepo.save(user);
		 return null;
		
	}
	
	@DeleteMapping("/{id}")
	public Mono<Void> delete(@PathVariable Integer id){
		
		userrepo.deleteById(id);
		
		return null;
		
	}
	
	
}
