package com.project.ams.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Generated;
import lombok.NoArgsConstructor;


@Table(name="User_tbl")
@AllArgsConstructor
@NoArgsConstructor
public class User {

	@Id	
	private Integer Id;
	
	
	private String UserName;
	
	
	private String Password;
	
	
	private String email;
	
	
}
